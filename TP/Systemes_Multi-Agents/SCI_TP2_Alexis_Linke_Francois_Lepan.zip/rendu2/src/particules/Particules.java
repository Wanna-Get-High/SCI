package particules;

import java.util.ArrayList;

import core.Agent;
import core.Environment;



public class Particules extends Environment {

	public Particules(int size) {
		super(size);
	}

	@Override
	public void addAgentsTo(ArrayList<Agent> agents) {}

	@Override
	public void removeAgentsTo(ArrayList<Agent> agents) {}

	@Override
	public void writeData() {}
}
